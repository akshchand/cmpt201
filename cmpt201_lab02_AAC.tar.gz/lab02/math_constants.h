#define MATH_CONSTANTS_H

#define PI 3.1415926535897932 // define pi to 16 digits after the decimal place