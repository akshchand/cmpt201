#define TRIG_H

#define N 2 // define n as a double precision constant