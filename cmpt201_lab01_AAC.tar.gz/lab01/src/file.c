#include <stdio.h>

int main(void)
{
    printf("Welcome to CMPT 201\n"); // print desired text to user
    return 0; // exit function
}